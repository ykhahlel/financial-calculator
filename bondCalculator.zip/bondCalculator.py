# -*- coding: utf-8 -*-
"""
Created on Wed May 17 14:29:57 2023

@author: Sthabiso
"""

print("Investment  - to calculate the amount of interest you'll earn on interest.")
print("Bond  - to calculate the amount you'll have to pay on a home loan.")
Type = input("Please enter Investment or Bond: ")


if(Type == "bond" or "Bond" or "BOND"):
       
    Present = float(input("Please enter type of Present Value: "))
    Interest = float(input("Please enter the monthly interest rate: "))/(100*12)
    Months = float(input("Please enter the number of months over which the bond will be repaid: "))
    
    def bondRepayment(Present, Months, Interest):
                
        return (Interest*Present)/(1-(1+Interest)**(-Months))
    
    rePay = int(bondRepayment(Present, Months, Interest))            
    print("The bond repayment over", Months, "months will be: R", rePay)
    
 
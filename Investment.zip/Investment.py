print("Investment  - to calculate the amount of interest you'll earn on interest.")
print("Bond  - to calculate the amount you'll have to pay on a home loan.")
Type = input("Please enter Investment or Bond: ")

if(Type == "Investment" or "investment" or "INVESTMENT"):
    
    Model = input("Please enter type of investment: ")
    Deposit = float(input("Please enter the investment amount: "))
    Interest = float(input("Please enter the interest rate in percentage: "))
    Time = float(input("Please enter the number of years for your investment: "))

    def bondInterest(Deposit, Time, Interest):
        
        if (Model == "simple"):
            return Deposit*(1 + (Interest/100)*Time) 
        
        elif (Model == "compound"):
            return Deposit*(1 + (Interest/100))**Time
    
    Acc = bondInterest(Deposit, Time, Interest)
    print("The accumulated amount after",Time, "year will be: R", Acc)
            